(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [705], {
        5929: function(n, t, u) {
            "use strict";
            u.r(t);
            var r = u(5893),
                s = u(8564),
                a = u(1806);
            t.default = function() {
                var n = (0, s.oW)();
                return (0, r.jsxs)(r.Fragment, {
                    children: [(0, r.jsx)(a.Z, {
                        data: n
                    }), (0, r.jsx)("div", {
                        className: "mt-10"
                    })]
                })
            }
        },
        2599: function(n, t, u) {
            (window.__NEXT_P = window.__NEXT_P || []).push(["/apps", function() {
                return u(5929)
            }])
        }
    },
    function(n) {
        n.O(0, [774, 351, 803], (function() {
            return t = 2599, n(n.s = t);
            var t
        }));
        var t = n.O();
        _N_E = t
    }
]);