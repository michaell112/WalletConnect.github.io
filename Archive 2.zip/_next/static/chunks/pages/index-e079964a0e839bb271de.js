(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [405], {
        5722: function(n, e, t) {
            "use strict";
            t.r(e);
            var a = t(5893),
                s = t(8564),
                c = t(1806);
            e.default = function() {
                var n = (0, s.go)();
                return (0, a.jsxs)("main", {
                    className: "flex flex-col mx-8 mt-12 space-y-10 text-center align-middle",
                    children: [(0, a.jsx)(c.Z, {
                        data: n
                    }), (0, a.jsx)("div", {
                        className: "mt-10"
                    })]
                })
            }
        },
        5301: function(n, e, t) {
            (window.__NEXT_P = window.__NEXT_P || []).push(["/", function() {
                return t(5722)
            }])
        }
    },
    function(n) {
        n.O(0, [774, 351, 803], (function() {
            return e = 5301, n(n.s = e);
            var e
        }));
        var e = n.O();
        _N_E = e
    }
]);