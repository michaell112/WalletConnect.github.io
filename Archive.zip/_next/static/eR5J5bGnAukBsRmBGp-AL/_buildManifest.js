self.__BUILD_MANIFEST = function(e) {
    return {
        __rewrites: {
            beforeFiles: [],
            afterFiles: [],
            fallback: []
        },
        "/": [e, "static/chunks/pages/index-e079964a0e839bb271de.js"],
        "/_error": ["static/chunks/pages/_error-42ea3d379d660ebca13f.js"],
        "/apps": [e, "static/chunks/pages/apps-873693e48e2cacbc2992.js"],
        "/wallets": [e, "static/chunks/pages/wallets-0a4e32dd47f4f93de59f.js"],
        sortedPages: ["/", "/_app", "/_error", "/apps", "/wallets"]
    }
}("static/chunks/803-a4d9fcae64a01015c673.js"), self.__BUILD_MANIFEST_CB && self.__BUILD_MANIFEST_CB();